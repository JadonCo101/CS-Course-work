/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 sad sad.png 
 * Time-stamp: Wednesday 11/09/2022, 04:48:10
 * 
 * Image Information
 * -----------------
 * sad.png 60@60
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAD_H
#define SAD_H

extern const unsigned short sad[3600];
#define SAD_SIZE 7200
#define SAD_LENGTH 3600
#define SAD_WIDTH 60
#define SAD_HEIGHT 60

#endif

