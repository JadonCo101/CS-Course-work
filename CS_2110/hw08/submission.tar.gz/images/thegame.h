/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 thegame thegame.png 
 * Time-stamp: Wednesday 11/09/2022, 02:52:38
 * 
 * Image Information
 * -----------------
 * thegame.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef THEGAME_H
#define THEGAME_H

extern const unsigned short thegame[38400];
#define THEGAME_SIZE 76800
#define THEGAME_LENGTH 38400
#define THEGAME_WIDTH 240
#define THEGAME_HEIGHT 160

#endif

