/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 winlose winlose.png 
 * Time-stamp: Wednesday 11/09/2022, 04:40:40
 * 
 * Image Information
 * -----------------
 * winlose.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINLOSE_H
#define WINLOSE_H

extern const unsigned short winlose[38400];
#define WINLOSE_SIZE 76800
#define WINLOSE_LENGTH 38400
#define WINLOSE_WIDTH 240
#define WINLOSE_HEIGHT 160

#endif

