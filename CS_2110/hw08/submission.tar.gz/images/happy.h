/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 happy happy.png 
 * Time-stamp: Wednesday 11/09/2022, 04:51:47
 * 
 * Image Information
 * -----------------
 * happy.png 60@60
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HAPPY_H
#define HAPPY_H

extern const unsigned short happy[3600];
#define HAPPY_SIZE 7200
#define HAPPY_LENGTH 3600
#define HAPPY_WIDTH 60
#define HAPPY_HEIGHT 60

#endif

