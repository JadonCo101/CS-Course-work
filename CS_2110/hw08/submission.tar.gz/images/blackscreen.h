/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 blackscreen blackscreen.png 
 * Time-stamp: Wednesday 11/09/2022, 21:20:56
 * 
 * Image Information
 * -----------------
 * blackscreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLACKSCREEN_H
#define BLACKSCREEN_H

extern const unsigned short blackscreen[38400];
#define BLACKSCREEN_SIZE 76800
#define BLACKSCREEN_LENGTH 38400
#define BLACKSCREEN_WIDTH 240
#define BLACKSCREEN_HEIGHT 160

#endif

