/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 sprite sprite.png 
 * Time-stamp: Wednesday 11/09/2022, 04:21:11
 * 
 * Image Information
 * -----------------
 * sprite.png 50@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPRITE_H
#define SPRITE_H

extern const unsigned short sprite[1250];
#define SPRITE_SIZE 2500
#define SPRITE_LENGTH 1250
#define SPRITE_WIDTH 50
#define SPRITE_HEIGHT 25

#endif

