Main Function:


Screens:
1) Start Screen
2) Instruction Screen
3) Play Screen
4) Win & Lose Screen

To win, you have to touch the moving square while it is green;
To lose, you have to touch the moving square while it is red;


Requirements/Has:
- 2 distinct background images and two distinct images smaller than the background
- Ability to reset program by pressing backspace
- Button input matters (arrow keys during the game, enter/return to start the game, z to start game from instructions screen)
- 2 dimensional movement with the player, can press up/down key together with right/left key (diagonal movement)
- object collision detected between player and moving square
- instructions screen provides useful text/information (how to play the game)
- score counter on the screen that provides useful information (lose when score < -10 and win when score > 50)
- no tearing in the program
- README file for the description
- implementing waitforVBlank();
- Uses three structs (one for the states, another for the player, and the last for the enemy or moving square)
- struct definitions and other defines in main.h file

